import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ConversationTurn {
  role: "user" | "assistant";
  content: string;
}

interface JournalRequest {
  userText: string;
  cyclePhase: string;
  protocolPhase: number;
  energy: string;
  bodySnapshot: Record<string, any>;
  confidenceSnapshot: Record<string, any>;
  masterySnapshot: Record<string, any>;
  intentionalAction?: string;
  history?: ConversationTurn[];
  userName?: string | null;
}

function buildSystemPrompt(userName?: string | null): string {
  const nameNote = userName ? ` The user's name is ${userName} — use it occasionally (not every message) to keep things warm and personal.` : '';
  return `You are Camryn, a calm, supportive wellness protocol companion. You know the user's body patterns, confidence notes, cycle phase, and habit streaks.${nameNote}

Your role is to have a genuine back-and-forth conversation. You reflect what you notice, ask a thoughtful follow-up question when it would help the user go deeper, and suggest one small specific next step when the moment is right.

Guidelines:
- Keep each reply to 2–3 short paragraphs maximum.
- Sound like a warm, perceptive friend who knows them well — not a health coach or doctor.
- Never diagnose, prescribe, or give medical advice.
- Never give generic wellness tips that ignore the context provided.
- If this is their first message ever (no history, little data), acknowledge that warmly: "I'm still getting to know your patterns — even a few more days of logging will help me notice what really matters for you."
- In follow-up turns, build on what they've already shared — reference it directly, don't start fresh.
- If they're going deeper into something, ask one focused follow-up question instead of immediately suggesting next steps.
- End with exactly one gentle, believable next step OR one good follow-up question — not both.
- Use "you" not "one". Be specific to what they've shared.`;
}

function buildContextBlock(req: JournalRequest): string {
  const lines: string[] = [];
  lines.push("Context about today:");

  if (req.cyclePhase && req.cyclePhase !== "Not sure") {
    lines.push(`- Cycle phase: ${req.cyclePhase}`);
  }
  lines.push(`- Protocol phase: ${req.protocolPhase}`);
  if (req.energy) lines.push(`- Session energy: ${req.energy}`);

  if (req.bodySnapshot && Object.keys(req.bodySnapshot).length > 0) {
    const b = req.bodySnapshot;
    if (b.energy != null) lines.push(`- Body energy score: ${b.energy}/5`);
    if (b.symptoms) lines.push(`- Symptoms noted: ${b.symptoms}`);
    if (b.cycle_status) lines.push(`- Cycle status: ${b.cycle_status}`);
    const vitsTaken = b.vitamins
      ? Object.entries(b.vitamins as Record<string, boolean>)
          .filter(([, v]) => v)
          .map(([k]) => k)
          .join(", ")
      : "";
    if (vitsTaken) lines.push(`- Vitamins taken: ${vitsTaken}`);
  }

  if (req.confidenceSnapshot?.confidence_note) {
    lines.push(`- Confidence note: ${req.confidenceSnapshot.confidence_note}`);
  }

  if (req.masterySnapshot) {
    const streaks = Object.entries(req.masterySnapshot as Record<string, number>)
      .map(([k, v]) => `${k}: ${v} day streak`)
      .join(", ");
    if (streaks) lines.push(`- Active streaks: ${streaks}`);
  }

  if (req.intentionalAction) {
    lines.push(`- Today's intentional action (${req.cyclePhase} phase): "${req.intentionalAction}"`);
  }

  return lines.join("\n");
}

function buildMessages(req: JournalRequest): ConversationTurn[] {
  const contextBlock = buildContextBlock(req);
  const history = req.history ?? [];

  if (history.length === 0) {
    // First message: inject context alongside the user's text
    return [
      {
        role: "user",
        content: `${contextBlock}\n\nToday's journal entry:\n"${req.userText}"`,
      },
    ];
  }

  // Follow-up: context was already sent in the first turn — just continue naturally
  // Inject context reminder only in the first turn of existing history if not already there
  const messages: ConversationTurn[] = history.map((h) => ({
    role: h.role,
    content: h.content,
  }));

  messages.push({ role: "user", content: req.userText });
  return messages;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: JournalRequest = await req.json();

    if (!body.userText?.trim()) {
      return new Response(
        JSON.stringify({ error: "userText is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("ANTHROPIC_API_KEY");

    if (!apiKey) {
      const fallback = generateFallbackReply(body);
      return new Response(
        JSON.stringify({ reply: fallback, fallback: true }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const messages = buildMessages(body);

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5",
        max_tokens: 500,
        system: buildSystemPrompt(body.userName),
        messages,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.error("Anthropic error:", err);
      return new Response(
        JSON.stringify({ reply: generateFallbackReply(body), fallback: true }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const reply = data.content?.[0]?.text ?? generateFallbackReply(body);

    return new Response(
      JSON.stringify({ reply }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Journal edge function error:", err);
    return new Response(
      JSON.stringify({ reply: "Camryn had trouble responding just now, but your entry is saved. Try again in a bit.", fallback: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function generateFallbackReply(req: JournalRequest): string {
  const phaseLines: Record<string, string> = {
    Follicular: "You're in a window that's genuinely good for building new patterns — your brain is more receptive right now than at most other points in your cycle.",
    Ovulation: "This is a high-output window for you. Whatever felt strong today, it's worth noting — your body is primed to perform.",
    "Early luteal": "The luteal phase rewards consistency over intensity. Showing up steadily matters more than pushing hard right now.",
    "Late luteal": "Late luteal asks for gentleness. Whatever you managed today counts — protecting your sleep and magnesium now will soften the next few days.",
    Menstruation: "Rest isn't passive during menstruation — it's what allows the next phase to feel strong. You're doing the right thing by tuning in.",
  };

  const phaseNote = phaseLines[req.cyclePhase] || "Your patterns are worth paying attention to — every entry builds a clearer picture.";

  return `${phaseNote}\n\nYour entry is saved. One small next step for today: whatever felt hardest, let that be the thing you make slightly easier tomorrow — not by skipping it, but by reducing one piece of friction around it.`;
}
