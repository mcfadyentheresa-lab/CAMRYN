export interface CycleProtocolAction {
  phase: string;
  protocolActionId: string;
}

export interface CycleIntentionalAction {
  phase: string;
  text: string;
  done: boolean;
}

const PROTOCOL_KEY = 'camrynCycleNewAction';
const INTENTIONAL_KEY = 'camrynIntentionalActions';

function today(): string {
  return new Date().toISOString().split('T')[0];
}

function loadMap(key: string): Record<string, any> {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveMap(key: string, map: Record<string, any>): void {
  localStorage.setItem(key, JSON.stringify(map));
}

// ── Protocol action pick ─────────────────────────

export function getProtocolActionPick(): CycleProtocolAction | null {
  return loadMap(PROTOCOL_KEY)[today()] ?? null;
}

export function saveProtocolActionPick(phase: string, protocolActionId: string): void {
  const map = loadMap(PROTOCOL_KEY);
  map[today()] = { phase, protocolActionId };
  saveMap(PROTOCOL_KEY, map);
}

export function clearProtocolActionPick(): void {
  const map = loadMap(PROTOCOL_KEY);
  delete map[today()];
  saveMap(PROTOCOL_KEY, map);
}

// ── Intentional action ───────────────────────────

export function getIntentionalAction(): CycleIntentionalAction | null {
  return loadMap(INTENTIONAL_KEY)[today()] ?? null;
}

export function saveIntentionalAction(phase: string, text: string): void {
  const map = loadMap(INTENTIONAL_KEY);
  const existing = map[today()];
  map[today()] = { phase, text, done: existing?.done ?? false };
  saveMap(INTENTIONAL_KEY, map);
}

export function toggleIntentionalDone(): void {
  const map = loadMap(INTENTIONAL_KEY);
  const entry = map[today()];
  if (!entry) return;
  map[today()] = { ...entry, done: !entry.done };
  saveMap(INTENTIONAL_KEY, map);
}
