export interface Quest {
  id: string;
  title: string;
  targetDays: number;
  soft: boolean; // biased toward for new users
}

export interface QuestState {
  targetDays: number;
  completedDates: string[];
}

export interface MasteryData {
  quests: Record<string, QuestState>;
  pickDate: string;
  pickId: string;
}

export const FOUNDATION_QUESTS: Quest[] = [
  { id: 'fixed-sleep',        title: 'Fixed sleep/wake time',       targetDays: 21, soft: false },
  { id: 'morning-hydration',  title: 'Morning hydration',           targetDays: 14, soft: true  },
  { id: 'fiber-goal',         title: 'Fiber goal met',              targetDays: 14, soft: false },
  { id: 'fermented-food',     title: 'Fermented food daily',        targetDays: 14, soft: false },
  { id: 'daily-checkin',      title: 'Daily 5-minute check-in',     targetDays: 14, soft: true  },
];

const STORAGE_KEY = 'camrynMasteryFoundation';

export function loadMasteryData(): MasteryData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as MasteryData;
  } catch {
    // fall through to default
  }
  return {
    quests: Object.fromEntries(
      FOUNDATION_QUESTS.map((q) => [q.id, { targetDays: q.targetDays, completedDates: [] }])
    ),
    pickDate: '',
    pickId: '',
  };
}

export function saveMasteryData(data: MasteryData): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

// Consecutive streak ending on or before today
export function calcStreak(completedDates: string[], targetDays: number): number {
  const today = new Date().toISOString().split('T')[0];
  const sorted = [...completedDates].sort().reverse();
  let streak = 0;
  let cursor = today;
  for (const d of sorted) {
    if (d === cursor) {
      streak++;
      cursor = prevDay(cursor);
      if (streak >= targetDays) break;
    } else if (d < cursor) {
      break;
    }
  }
  return streak;
}

function prevDay(dateStr: string): string {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate() - 1);
  return d.toISOString().split('T')[0];
}

export function isTodayCompleted(completedDates: string[]): boolean {
  const today = new Date().toISOString().split('T')[0];
  return completedDates.includes(today);
}

export function toggleToday(completedDates: string[]): string[] {
  const today = new Date().toISOString().split('T')[0];
  return completedDates.includes(today)
    ? completedDates.filter((d) => d !== today)
    : [...completedDates, today];
}

// Pick one incomplete quest for today — biased toward soft quests for new users
export function chooseDailyPick(data: MasteryData, totalDaysCompleted: number): string {
  const incompletes = FOUNDATION_QUESTS.filter((q) => {
    const state = data.quests[q.id];
    if (!state) return true;
    return calcStreak(state.completedDates, state.targetDays) < state.targetDays;
  });
  if (incompletes.length === 0) return '';

  // new users (< 7 total days): bias heavily toward soft quests
  const pool =
    totalDaysCompleted < 7
      ? incompletes.filter((q) => q.soft).length > 0
        ? incompletes.filter((q) => q.soft)
        : incompletes
      : incompletes;

  const idx = Math.floor(Math.random() * pool.length);
  return pool[idx].id;
}

export function ensureDailyPick(data: MasteryData): MasteryData {
  const today = new Date().toISOString().split('T')[0];
  if (data.pickDate === today && data.pickId) return data;

  const totalDone = Object.values(data.quests).reduce(
    (acc, qs) => acc + qs.completedDates.length,
    0
  );
  const pickId = chooseDailyPick(data, totalDone);
  return { ...data, pickDate: today, pickId };
}
