export const PROTOCOL = {
  phases: [
    {
      id: 1,
      name: 'Foundation',
      weeks: '1–6',
      focus: 'Gut, sleep, hydration, baseline habits',
      promise: 'This phase is about creating safety and stability in your body.',
      why: 'Sleep, hydration, gut health, and stress regulation are the highest-leverage foundations because they shape hormones, energy, digestion, appetite, mood, and recovery.',
      modules: [
        {
          title: 'Sleep Protocol',
          why: 'Sleep is the recovery engine for hormones, hunger signals, skin repair, and energy.',
          actions: ['Wake up at your planned time', 'No screens 45 min before bed', 'Cool, dark, quiet room'],
        },
        {
          title: 'Hydration Protocol',
          why: 'Hydration reduces false hunger, brain fog, and low energy.',
          actions: ['500ml water on waking', 'Aim for 2.5–3L daily', 'Swap one caffeinated drink'],
        },
        {
          title: 'Gut Foundation',
          why: 'A healthier gut supports metabolism, inflammation balance, and steadier appetite.',
          actions: ['Aim for 25–35g fiber', 'One fermented food daily', 'Increase plant diversity'],
        },
      ],
      mastery: [
        'Fixed sleep/wake time for 21 consecutive days',
        'Morning hydration for 14 consecutive days',
        'Fiber goal met for 2 consecutive weeks',
        'Fermented food daily for 14 days',
        'Daily 5-minute check-in for 14 days',
      ],
    },
    {
      id: 2,
      name: 'Ignition',
      weeks: '7–12',
      focus: 'Nutrition, movement, skin & hair starts',
      promise: 'This is where your transformation starts to feel active.',
      why: 'Protein, structured meals, walking, early strength, skincare, and hair support create visible traction without demanding perfection.',
      modules: [
        {
          title: 'Nutrition Architecture',
          why: 'Protein, fiber, and meal structure support body composition and hormone steadiness.',
          actions: ['Set protein target', 'Use the plate model', 'Use an 8–10 hour eating window'],
        },
        {
          title: 'Movement Foundation',
          why: 'Walking and beginner strength create momentum and body trust.',
          actions: ['Walk daily', 'Add bodyweight strength twice weekly', 'Progress patiently'],
        },
        {
          title: 'Skin + Hair Start',
          why: 'Consistency beats complexity. Repetition creates payoff.',
          actions: ['AM skincare with SPF', 'PM skincare with retinol progression', 'Collagen + scalp massage'],
        },
      ],
      mastery: [
        'Protein target 5/7 days for 3 weeks',
        'Eating window maintained for 14 days',
        'Daily walk for 30 days',
        'Strength 2x/week for 4 weeks',
        'Skincare routine for 30 days',
      ],
    },
    {
      id: 3,
      name: 'Build',
      weeks: '13–22',
      focus: 'Body composition, hormone tuning, joints',
      promise: 'Now your body begins to adapt to your standards.',
      why: 'Strength training, hormone support, and joint care help your body become stronger, more resilient, and easier to maintain.',
      modules: [
        {
          title: 'Body Composition',
          why: 'Muscle changes metabolism, shape, and long-term maintenance capacity.',
          actions: ['Add a third strength day', 'Use progressive overload', 'Focus on compound patterns'],
        },
        {
          title: 'Hormone Balance',
          why: 'Hormones influence cravings, sleep, cycle quality, and fat storage.',
          actions: ['Add magnesium glycinate', 'Try seed cycling', 'Get baseline hormone labs'],
        },
        {
          title: 'Joint Health',
          why: 'Longevity matters. Joints determine how well you can keep going.',
          actions: ['Daily mobility routine', 'Omega-3 daily', 'Alternate high/low impact weeks'],
        },
      ],
      mastery: [
        'Cycle-adapted training for 8 weeks',
        'Joint mobility for 30 days',
        'Omega-3 for 60 days',
        'Hormone support stack for 60 days',
        'Hormone bloodwork completed',
      ],
    },
  ],
  quotes: [
    'A protocol becomes powerful when it feels like guidance, not punishment.',
    'Small proof every day is more powerful than dramatic effort once in a while.',
    'You are building a body that can hold the life you want.',
  ],
  energy: ['Low', 'Medium', 'High'],
  stress: ['Low', 'Moderate', 'High', 'Very high'],
};

export interface DailyLearn {
  title: string;
  body: string;
  tag: string;
}

export const DAILY_LEARNS: DailyLearn[] = [
  // Cycle & hormones
  { title: 'Estrogen rises in the follicular phase', body: 'During days 1–13 of your cycle, rising estrogen improves mood, neuroplasticity, and insulin sensitivity — your brain literally forms new habits more easily right now.', tag: 'Cycle' },
  { title: 'Ovulation boosts social energy', body: 'At ovulation, estrogen peaks and your voice pitch, confidence, and social drive naturally rise. Use this window for hard conversations, presentations, or anything requiring presence.', tag: 'Cycle' },
  { title: 'Progesterone asks for rest', body: 'In the luteal phase, progesterone raises your resting body temperature and metabolic rate slightly — you need 100–300 more calories and more sleep to feel even.', tag: 'Cycle' },
  { title: 'Late luteal is a signal, not a problem', body: 'PMS symptoms like bloating, irritability, and cravings are your body communicating. Low magnesium, poor sleep, and high stress amplify them significantly.', tag: 'Cycle' },
  { title: 'Menstruation is a monthly review', body: 'Your period quality reflects the hormonal environment of the past 4–6 weeks — not just the current week. Heavy, painful, or irregular periods are data worth tracking.', tag: 'Cycle' },
  { title: 'Cycle length varies more than you think', body: 'A "normal" cycle is 21–35 days. Only about 15% of people have a textbook 28-day cycle. Tracking your own pattern matters more than any average.', tag: 'Cycle' },
  // Sleep
  { title: 'Sleep is your number one hormone regulator', body: 'A single night under 6 hours raises cortisol, lowers leptin (fullness hormone), and elevates ghrelin (hunger hormone) — making food choices significantly harder the next day.', tag: 'Sleep' },
  { title: 'Your cortisol should peak in the morning', body: 'Cortisol awakening response (CAR) is highest in the first 30–45 min after waking. Natural light exposure amplifies this, improving focus and suppressing evening cortisol.', tag: 'Sleep' },
  { title: 'Core body temp drives sleep onset', body: 'Your body needs to drop 1–2°C to fall asleep. A cool room (16–19°C), a warm bath 1–2 hrs before bed, or socks help speed this process.', tag: 'Sleep' },
  { title: 'Screens delay melatonin by 90 minutes', body: 'Blue light from phones suppresses melatonin production. Switching to dim, warm lighting after sunset can shift your natural sleep window earlier without effort.', tag: 'Sleep' },
  // Gut & nutrition
  { title: 'Fiber feeds your gut microbiome', body: 'Different fibers feed different bacteria. Eating 30+ different plant foods per week produces a more diverse microbiome — associated with better mood, immunity, and hormonal balance.', tag: 'Gut' },
  { title: 'The gut-brain axis is bidirectional', body: '90% of serotonin is made in the gut. Chronic gut inflammation can dysregulate mood, energy, and stress response — gut health is mental health.', tag: 'Gut' },
  { title: 'Protein timing matters at breakfast', body: 'A protein-rich breakfast (25–35g) stabilises blood sugar, reduces cravings by midday, and supports lean mass. Skipping breakfast amplifies cortisol-driven hunger later.', tag: 'Nutrition' },
  { title: 'Magnesium is depleted by stress', body: 'Magnesium supports over 300 enzymatic processes including sleep, muscle relaxation, and PMS reduction. Chronic stress, sugar, and alcohol all accelerate depletion.', tag: 'Nutrition' },
  // Hydration
  { title: 'Thirst is a late signal', body: 'By the time you feel thirsty, you are already 1–2% dehydrated — enough to reduce concentration, increase fatigue, and trigger false hunger. Morning hydration resets this.', tag: 'Hydration' },
  { title: 'Electrolytes matter as much as water', body: 'Drinking large amounts of plain water without electrolytes can dilute sodium and worsen bloating, fatigue, and headaches. A pinch of salt or electrolyte mineral helps absorption.', tag: 'Hydration' },
  // Stress & nervous system
  { title: 'Chronic stress shrinks the hippocampus', body: 'Prolonged high cortisol reduces grey matter in the hippocampus — the memory and emotional regulation centre. Consistent sleep, movement, and magnesium are protective.', tag: 'Stress' },
  { title: 'Exhale length determines calm', body: 'A longer exhale than inhale activates the parasympathetic nervous system. A 4-count inhale and 6-count exhale is enough to reduce heart rate within 3 breaths.', tag: 'Stress' },
  { title: 'Cold exposure lowers baseline cortisol', body: 'Regular cold exposure (even 30-second cold showers) trains the stress response, reducing baseline cortisol and improving mood through norepinephrine release over time.', tag: 'Stress' },
  // Body composition
  { title: 'Strength training is the best metabolic investment', body: 'Muscle tissue burns 3x more energy at rest than fat tissue. Adding muscle mass raises your baseline calorie burn 24 hours a day — not just during exercise.', tag: 'Fitness' },
  { title: 'Walking is underrated', body: 'A daily 30-minute walk reduces all-cause mortality risk by 35%, improves insulin sensitivity, lowers cortisol, and doesn\'t spike recovery demands like intense cardio.', tag: 'Fitness' },
  { title: 'Protein preserves muscle during fat loss', body: 'Eating 1.6–2.2g of protein per kg of bodyweight while in a calorie deficit preserves lean mass. Without adequate protein, weight loss comes partly from muscle.', tag: 'Nutrition' },
  // Skin & lymph
  { title: 'Skin reflects internal inflammation', body: 'Breakouts, dullness, and puffiness are often downstream of gut inflammation, hormonal shifts, or high glycaemic load — not just a skincare problem.', tag: 'Skin' },
  { title: 'Lymph fluid moves with your muscles', body: 'Unlike blood, lymph has no pump. It relies entirely on movement and breathing to circulate. Gentle walking, stretching, or rebounding clears waste and reduces puffiness.', tag: 'Body' },
];

export function dailyLearnForToday(cyclePhaseName: string): DailyLearn {
  const today = new Date().toISOString().split('T')[0];
  const seed = today.replace(/-/g, '').split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);

  const cycleTagged = DAILY_LEARNS.filter(l => l.tag === 'Cycle');
  const phasePrefer: Record<string, string[]> = {
    'Follicular':   ['Cycle', 'Nutrition', 'Fitness'],
    'Ovulation':    ['Cycle', 'Stress', 'Fitness'],
    'Early luteal': ['Cycle', 'Stress', 'Sleep'],
    'Late luteal':  ['Cycle', 'Nutrition', 'Gut'],
    'Menstruation': ['Cycle', 'Sleep', 'Body'],
    'Not sure':     ['Sleep', 'Hydration', 'Gut', 'Stress'],
  };
  const preferred = phasePrefer[cyclePhaseName] || [];
  const pool = preferred.length
    ? DAILY_LEARNS.filter(l => preferred.includes(l.tag))
    : DAILY_LEARNS;

  return pool[seed % pool.length] || cycleTagged[0];
}

export const CYCLE_PHASES = [
  { name: 'Menstruation', desc: 'rest, gentle movement, nourishment' },
  { name: 'Follicular', desc: 'learning, new habits, moderate workouts' },
  { name: 'Ovulation', desc: 'challenge, connection, higher output' },
  { name: 'Early luteal', desc: 'deep practice, steadier effort' },
  { name: 'Late luteal', desc: 'wind-down, soothing rituals, review' },
  { name: 'Not sure', desc: 'cycle-neutral guidance based on energy and phase' },
];

export function cyclePhaseFromName(name: string) {
  return CYCLE_PHASES.find((p) => p.name === name) || CYCLE_PHASES[3];
}

export function dayOfCycleFromDate(dateStr: string): number | null {
  if (!dateStr) return null;
  const start = new Date(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  start.setHours(0, 0, 0, 0);
  const diff = Math.floor((today.getTime() - start.getTime()) / 86400000) + 1;
  if (diff < 1) return null;
  return ((diff - 1) % 28) + 1;
}

export function phaseFromDay(day: number) {
  if (day <= 6) return CYCLE_PHASES[0];
  if (day <= 13) return CYCLE_PHASES[1];
  if (day <= 16) return CYCLE_PHASES[2];
  if (day <= 24) return CYCLE_PHASES[3];
  return CYCLE_PHASES[4];
}

export function taskTier(energy: string) {
  if (energy === 'Low') return { name: 'Tier 1', tone: 'Start softly' };
  if (energy === 'Medium') return { name: 'Tier 2', tone: 'Good working rhythm' };
  return { name: 'Tier 3', tone: 'Use your energy well' };
}

export function dailyTasks(
  phase: number,
  energy: string,
  stress: string,
  cyclePhaseName: string
) {
  const cyc = cyclePhaseFromName(cyclePhaseName);
  const e = energy;
  const s = stress;

  const phaseTasks: Record<string, Record<string, any>> = {
    1: {
      Low: {
        title:
          'Drink 500ml of water within 10 minutes of waking — before coffee, before your phone.',
        body: 'Cortisol is naturally elevated on waking and dehydration amplifies it. This one act sets your hormonal tone for the morning and is the single highest-return action in Phase 1.',
        tag: 'Foundation · Hydration',
      },
      Medium: {
        title:
          'Eat 25–35g of fiber today from at least 3 different plant sources (legumes, vegetables, fruit, or wholegrains).',
        body: 'Fiber diversity feeds your gut microbiome, which directly regulates estrogen clearance, inflammation, and appetite signals. More variety means more benefit — this is not optional in Phase 1.',
        tag: 'Foundation · Gut',
      },
      High: {
        title: 'Set one fixed wake time for the rest of this week and hold it regardless of bedtime.',
        body: 'A consistent wake time anchors your circadian rhythm faster than a consistent bedtime. It regulates cortisol, melatonin, and hunger hormones within days. This is the foundation all other habits depend on.',
        tag: 'Foundation · Sleep',
      },
    },
    2: {
      Low: {
        title:
          'Eat a protein-anchored breakfast within 60–90 minutes of waking. Aim for at least 25–30g of protein.',
        body: 'Morning protein blunts the cortisol spike, stabilises blood sugar, and reduces afternoon cravings. This is the highest-return nutrition move in Phase 2 and the one most people underdo.',
        tag: 'Ignition · Nutrition',
      },
      Medium: {
        title:
          'Complete a 20–30 minute walk today, ideally outside. For the first 10 minutes, no earphones.',
        body: 'Walking is a direct cortisol reducer and insulin sensitiser. Unstructured outdoor movement also improves mood regulation and reduces mental noise — it is not just exercise, it is nervous system care.',
        tag: 'Ignition · Movement',
      },
      High: {
        title:
          'Complete your bodyweight strength session: 3 sets of squats, hip hinges, and push-ups. Rest 90 seconds between sets.',
        body: 'Compound strength training twice a week is the minimum effective dose for body composition change. Squats, hinges, and push-ups recruit the most muscle and produce the strongest hormonal response. Do not skip this session.',
        tag: 'Ignition · Strength',
      },
    },
    3: {
      Low: {
        title: 'Take 300–400mg of magnesium glycinate tonight, 30–60 minutes before bed.',
        body: 'Magnesium glycinate is the most bioavailable form and directly supports sleep quality, muscle recovery, and progesterone function in the luteal phase. It is the most evidence-backed supplement in this protocol.',
        tag: 'Build · Hormones',
      },
      Medium: {
        title:
          'Add a third strength session this week. Focus on progressive overload — add one rep or 2.5–5kg to at least one lift.',
        body: 'Progress requires a clear signal. Progressive overload is that signal — it tells your body to build more muscle, which changes your metabolism, shape, and hormonal health. Without it, you maintain. With it, you build.',
        tag: 'Build · Body Composition',
      },
      High: {
        title:
          'Complete 10–15 minutes of joint mobility: hips, thoracic spine, and ankles. Use slow, controlled movement through full range of motion.',
        body: 'Joints that move well allow you to train harder, recover faster, and sustain this protocol for years. Skipping mobility work is borrowing against your future capacity — do this even when it feels unnecessary.',
        tag: 'Build · Longevity',
      },
    },
  };

  const pk = String(phase);
  const phaseTask =
    (phaseTasks[pk] || phaseTasks['1'])[e] || (phaseTasks[pk] || phaseTasks['1']).Medium;

  let cycleTask: any;
  if (cyc.name === 'Menstruation') {
    cycleTask = {
      title:
        e === 'Low'
          ? 'Gentle movement only today: a slow walk, stretching, or yoga. Eat warm, iron-rich foods (lentils, spinach, red meat if you eat it). Rest is not optional — it is protocol.'
          : 'Keep movement gentle today. A light walk or slow yoga is appropriate. Avoid high-intensity training — inflammation is naturally elevated and recovery is slower during menstruation.',
      body: 'Estrogen and progesterone are at their lowest point in your cycle. Your body is doing real physiological work. Supporting it with rest, warmth, and iron-rich nutrition is the scientifically correct response — not the easy way out.',
      tag: 'Cycle · Menstruation',
    };
  } else if (cyc.name === 'Follicular') {
    cycleTask = {
      title:
        e === 'Low'
          ? 'Start one new protocol habit today. Write down exactly when and how you will do it — specificity is what makes it stick.'
          : 'Follicular phase is your best window for learning and habit installation. Introduce one new protocol action today with full intention — this is when new behaviours form most easily.',
      body: 'Rising estrogen in the follicular phase improves insulin sensitivity, mood, and neuroplasticity. Your brain is literally more receptive to forming new patterns right now. Use this window deliberately.',
      tag: 'Cycle · Follicular',
    };
  } else if (cyc.name === 'Ovulation') {
    cycleTask = {
      title:
        e === 'Low'
          ? 'Even on a lower energy day, ovulation is a high-performance window. Do at least one thing today that stretches your effort — a longer walk, a heavier lift, or a harder task.'
          : 'Push harder in your workout today — add weight, extend duration, or increase intensity. Ovulation is your highest-output window and training harder here produces a stronger adaptation signal.',
      body: 'Estrogen peaks at ovulation and testosterone briefly rises. Strength output, endurance, and pain tolerance are all at their highest during this window. This is not a coincidence — it is your biology supporting peak performance.',
      tag: 'Cycle · Ovulation',
    };
  } else if (cyc.name === 'Early luteal') {
    cycleTask = {
      title:
        e === 'Low'
          ? 'Maintain your protocol today — do not skip your non-negotiables. Eat enough protein (target 100–120g total) and protect your sleep window.'
          : 'Stay consistent with strength work but increase recovery focus. Add 15 minutes of extra sleep and slightly increase protein to support progesterone production.',
      body: 'Progesterone rises in the luteal phase, increasing body temperature, resting heart rate, and protein needs. Maintaining structure here prevents the energy and mood crash that many people experience in the second half of their cycle.',
      tag: 'Cycle · Early Luteal',
    };
  } else if (cyc.name === 'Not sure') {
    cycleTask = {
      title:
        e === 'Low'
          ? 'No cycle tracking today: focus on your phase protocol action and keep your protein and hydration targets as your anchors.'
          : 'No cycle tracking: your daily tasks are driven entirely by your protocol phase and energy level. Use this as a consistent baseline day.',
      body: 'When you are not tracking your cycle, your protocol phase and energy level are your two strongest guides. Consistency on these two inputs alone produces meaningful results.',
      tag: 'Cycle · Not Tracking',
    };
  } else {
    cycleTask = {
      title:
        e === 'Low' || s === 'High' || s === 'Very high'
          ? 'Late luteal non-negotiables today: sleep, magnesium, and cut added sugar and alcohol. These three actions directly reduce PMS severity — do not skip them because you feel worse. That is exactly when they matter most.'
          : 'Wind down training intensity today. Complete your mobility work, review this week in the protocol, and make tomorrow morning easy by prepping your water and supplements tonight.',
      body: 'What you do in late luteal determines how bad next week feels. Sleep, magnesium, and lower sugar are not mood-boosters — they are direct interventions on the hormonal drop that causes PMS. The worse you feel, the more these matter.',
      tag: 'Cycle · Late Luteal',
    };
  }

  let supportTask: any;
  if (s === 'Very high' || s === 'High') {
    supportTask = {
      title:
        'Before your next meal: do 4 rounds of 4-7-8 breathing (inhale 4 counts, hold 7, exhale 8 slowly). Then eat slowly and without screens.',
      body: 'High cortisol suppresses digestion, disrupts blood sugar regulation, and blocks progesterone production. Activating the parasympathetic nervous system before eating directly changes what your body does with the food. This is not a wellness suggestion — it is a physiological intervention.',
      tag: 'Stress Response · Regulation',
    };
  } else if (e === 'Low') {
    supportTask = {
      title:
        'On a low energy day, your one non-negotiable is protein at every meal. Even if nothing else goes to plan today, hit your protein target.',
      body: 'Protein is the most protective macro on a hard day. It stabilises blood sugar, prevents muscle breakdown, and prevents the mid-afternoon crash that derails the rest of the day. Everything else is optional today. Protein is not.',
      tag: 'Low Energy · Priority',
    };
  } else {
    supportTask = {
      title:
        'Review one mastery marker from your current phase and honestly assess your progress. What is working? What single thing is most likely to block you?',
      body: 'Protocol progress is built through honest self-assessment, not motivation. Identifying your real friction point lets you solve the right problem — which is almost never "not trying hard enough." It is usually a structure, environment, or knowledge gap.',
      tag: 'Protocol · Self-Assessment',
    };
  }

  return [phaseTask, cycleTask, supportTask];
}
