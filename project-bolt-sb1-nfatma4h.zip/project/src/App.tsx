import { useEffect, useState } from 'react';
import { supabase } from './lib/supabase';
import { PROTOCOL, dayOfCycleFromDate, phaseFromDay } from './lib/protocol';
import { FOUNDATION_QUESTS, loadMasteryData, calcStreak } from './lib/mastery';
import Header, { AppView } from './components/Header';
import MainContent from './components/MainContent';
import ProfileSection from './components/ProfileSection';
import BodySection from './components/BodySection';
import ConfidenceSection from './components/ConfidenceSection';
import SpaceSection from './components/SpaceSection';
import JournalSection from './components/JournalSection';
import CamrynOrb from './components/ui/CamrynOrb';
import './App.css';

interface Session {
  id: string;
  current_phase: number;
  cycle_phase_name: string;
  cycle_day: number | null;
  last_period_date: string | null;
  energy: string;
  stress: string;
  save_count: number;
  display_name: string | null;
}

interface Unlock {
  id: string;
  phase_id: number;
  unlock_index: number;
  title: string;
  total_days: number;
  remaining_days: number;
  status: string;
}

const PHASE_COLORS: Record<number, { fill: string; track: string; soft: string }> = {
  1: { fill: 'var(--phase-1)', track: 'var(--phase-1-track)', soft: 'var(--phase-1-soft)' },
  2: { fill: 'var(--phase-2)', track: 'var(--phase-2-track)', soft: 'var(--phase-2-soft)' },
  3: { fill: 'var(--phase-3)', track: 'var(--phase-3-track)', soft: 'var(--phase-3-soft)' },
};

function calcPhaseProgress(): number {
  const data = loadMasteryData();
  const totalTarget = FOUNDATION_QUESTS.reduce((acc, q) => acc + q.targetDays, 0);
  const totalEarned = FOUNDATION_QUESTS.reduce((acc, q) => {
    const qs = data.quests[q.id];
    if (!qs) return acc;
    return acc + Math.min(calcStreak(qs.completedDates, q.targetDays), q.targetDays);
  }, 0);
  return totalTarget > 0 ? Math.round((totalEarned / totalTarget) * 100) : 0;
}

interface PhaseProgressBarProps {
  phase: number;
  phaseName: string;
  pct: number;
}

function PhaseProgressBar({ phase, phaseName, pct }: PhaseProgressBarProps) {
  const colors = PHASE_COLORS[phase] || PHASE_COLORS[1];
  return (
    <div className="phase-top-bar" style={{ background: colors.soft }}>
      <div className="phase-top-bar-inner">
        <span className="phase-top-label" style={{ color: colors.fill }}>
          Phase {phase} · {phaseName}
        </span>
        <div className="phase-top-track" style={{ background: colors.track }}>
          <div
            className="phase-top-fill"
            style={{ width: `${pct}%`, background: colors.fill }}
          />
        </div>
        <span className="phase-top-pct" style={{ color: colors.fill }}>{pct}%</span>
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<Session | null>(null);
  const [unlocks, setUnlocks] = useState<Unlock[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [saveStatus, setSaveStatus] = useState('Not saved yet');
  const [view, setView] = useState<AppView>('today');
  const [phaseProgress, setPhaseProgress] = useState(() => calcPhaseProgress());

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session: authSession } } = await supabase.auth.getSession();
      setUser(authSession?.user || null);
      setLoading(false);

      if (authSession?.user) {
        loadSession(authSession.user.id);
      }
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, authSession) => {
      setUser(authSession?.user || null);
      if (authSession?.user) {
        loadSession(authSession.user.id);
      }
    });

    return () => subscription?.unsubscribe();
  }, []);

  const loadSession = async (userId: string) => {
    const { data: sessionData } = await supabase
      .from('camryn_sessions')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (sessionData) {
      // Backfill name from auth metadata if not yet saved in session
      if (!sessionData.display_name) {
        const { data: { user: authUser } } = await supabase.auth.getUser();
        const metaName = authUser?.user_metadata?.display_name as string | undefined;
        if (metaName) {
          const { data: updated } = await supabase
            .from('camryn_sessions')
            .update({ display_name: metaName })
            .eq('user_id', userId)
            .select()
            .maybeSingle();
          setSession((updated ?? sessionData) as Session);
        } else {
          setSession(sessionData as Session);
        }
      } else {
        setSession(sessionData as Session);
      }
    } else {
      const { data: { user: authUser } } = await supabase.auth.getUser();
      const metaName = authUser?.user_metadata?.display_name as string | undefined;
      const newSession = {
        user_id: userId,
        current_phase: 1,
        cycle_phase_name: 'Not sure',
        cycle_day: null,
        last_period_date: null,
        energy: 'Medium',
        stress: 'Moderate',
        save_count: 0,
        display_name: metaName ?? null,
      };
      const { data } = await supabase.from('camryn_sessions').insert([newSession]).select().maybeSingle();
      if (data) setSession(data as Session);
    }

    const { data: unlocksData } = await supabase
      .from('camryn_unlocks')
      .select('*')
      .eq('user_id', userId);
    setUnlocks(unlocksData as Unlock[] || []);
  };

  const updateSessionField = async (field: string, value: any) => {
    if (!session || !user) return;

    const { data } = await supabase
      .from('camryn_sessions')
      .update({ [field]: value })
      .eq('user_id', user.id)
      .select()
      .maybeSingle();

    if (data) setSession(data as Session);
  };

  const handleCycleDateChange = (dateStr: string) => {
    const day = dayOfCycleFromDate(dateStr);
    if (day) {
      const phase = phaseFromDay(day);
      updateSessionField('last_period_date', dateStr);
      updateSessionField('cycle_day', day);
      updateSessionField('cycle_phase_name', phase.name);
    }
  };

  const handleSaveDay = async (tasksComplete: number, tasksTotal: number) => {
    if (!user || !session) return;

    const today = new Date().toISOString().split('T')[0];
    const isComplete = tasksComplete === tasksTotal;

    await supabase
      .from('camryn_daily_saves')
      .upsert([
        {
          user_id: user.id,
          save_date: today,
          tasks_complete: tasksComplete,
          tasks_total: tasksTotal,
          is_complete: isComplete,
        },
      ], { onConflict: 'user_id,save_date' });

    applyUnlockProgress(isComplete);

    setSaveStatus(
      isComplete
        ? `Saved just now · ${tasksComplete}/${tasksTotal} tasks complete`
        : `Saved just now · progress paused at ${tasksComplete}/${tasksTotal}`
    );

    await updateSessionField('save_count', (session.save_count || 0) + 1);
  };

  const applyUnlockProgress = async (savedCompleteDay: boolean) => {
    if (!user || !session) return;

    const phase = PROTOCOL.phases.find((p) => p.id === session.current_phase) || PROTOCOL.phases[0];
    const countdownSeeds = [21, 14, 14, 14, 14];

    let newUnlocks = [...unlocks];

    phase.mastery.forEach((title, idx) => {
      const seed = countdownSeeds[idx] || 14 + idx * 7;
      let existing = newUnlocks.find(
        (u) => u.phase_id === session.current_phase && u.unlock_index === idx
      );

      if (!existing) {
        existing = {
          id: '',
          phase_id: session.current_phase,
          unlock_index: idx,
          title,
          total_days: seed,
          remaining_days: seed,
          status: 'not_started',
        };
        newUnlocks.push(existing);
      }

      if (savedCompleteDay) {
        if (existing.status === 'not_started') existing.status = 'active';
        if (existing.status === 'paused') existing.status = 'active';
        if (existing.status === 'active' && existing.remaining_days > 0) {
          existing.remaining_days -= 1;
        }
        if (existing.remaining_days <= 0) {
          existing.remaining_days = 0;
          existing.status = 'done';
        }
      } else {
        if (existing.status === 'active') existing.status = 'paused';
      }
    });

    setUnlocks(newUnlocks);

    for (const unlock of newUnlocks) {
      if (unlock.id) {
        await supabase
          .from('camryn_unlocks')
          .update({
            remaining_days: unlock.remaining_days,
            status: unlock.status,
          })
          .eq('id', unlock.id);
      } else {
        await supabase.from('camryn_unlocks').insert([
          {
            user_id: user.id,
            phase_id: unlock.phase_id,
            unlock_index: unlock.unlock_index,
            title: unlock.title,
            total_days: unlock.total_days,
            remaining_days: unlock.remaining_days,
            status: unlock.status,
          },
        ]);
      }
    }
  };

  const handleNameSave = async (name: string) => {
    if (!session || !user) return;
    const { data } = await supabase
      .from('camryn_sessions')
      .update({ display_name: name })
      .eq('user_id', user.id)
      .select()
      .maybeSingle();
    if (data) setSession(data as Session);
  };

  if (loading) {
    return <div style={{ padding: '20px', textAlign: 'center' }}>Loading...</div>;
  }

  if (!user) {
    return <AuthPrompt />;
  }

  if (!session) {
    return <div style={{ padding: '20px', textAlign: 'center' }}>Initializing...</div>;
  }

  const displayName = session.display_name?.trim() || null;

  return (
    <div data-theme={theme} style={{ background: 'var(--bg)', color: 'var(--ink)' }}>
      {!displayName && (
        <NamePrompt onSave={handleNameSave} />
      )}
      <div className="app">
        <Header
          theme={theme}
          onThemeToggle={() => setTheme(theme === 'light' ? 'dark' : 'light')}
          saveStatus={saveStatus}
          onSignOut={() => {
            supabase.auth.signOut();
            setUser(null);
          }}
          view={view}
          onViewChange={setView}
          currentPhase={session.current_phase}
          displayName={displayName}
        />

        <PhaseProgressBar
          phase={session.current_phase}
          phaseName={PROTOCOL.phases.find(p => p.id === session.current_phase)?.name || ''}
          pct={phaseProgress}
        />

        <div className="lane-view">
          {view === 'today' && (
            <MainContent
              session={session}
              unlocks={unlocks}
              onEnergyChange={(energy) => updateSessionField('energy', energy)}
              onStressChange={(stress) => updateSessionField('stress', stress)}
              onCyclePhaseChange={(name) => updateSessionField('cycle_phase_name', name)}
              onCycleDateChange={handleCycleDateChange}
              onSaveDay={handleSaveDay}
              onNavigateToJournal={() => setView('journal')}
              onPhaseProgressChange={setPhaseProgress}
            />
          )}
          {view === 'body' && (
            <div className="lane-single">
              <BodySection
                userId={user.id}
                cyclePhase={session.cycle_phase_name}
                cycleDay={session.cycle_day}
                lastPeriodDate={session.last_period_date}
                onCyclePhaseChange={(name) => updateSessionField('cycle_phase_name', name)}
                onCycleDateChange={handleCycleDateChange}
              />
            </div>
          )}
          {view === 'confidence' && (
            <div className="lane-single">
              <ConfidenceSection userId={user.id} />
            </div>
          )}
          {view === 'space' && (
            <div className="lane-single">
              <SpaceSection userId={user.id} />
            </div>
          )}
          {view === 'journal' && (
            <div className="lane-single">
              <JournalSection userId={user.id} session={session} displayName={displayName} />
            </div>
          )}
          {view === 'profile' && (
            <div className="lane-single">
              <ProfileSection userId={user.id} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function NamePrompt({ onSave }: { onSave: (name: string) => Promise<void> }) {
  const [name, setName] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) return;
    setSaving(true);
    await onSave(trimmed);
    setSaving(false);
  };

  return (
    <div className="name-prompt-overlay">
      <div className="name-prompt-card">
        <div className="name-prompt-avatar">
          <CamrynOrb size={72} />
        </div>
        <h2 className="name-prompt-title">Hi, I'm Camryn.</h2>
        <p className="name-prompt-sub">What should I call you?</p>
        <form onSubmit={handleSubmit} className="name-prompt-form">
          <input
            type="text"
            className="name-prompt-input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your first name"
            autoFocus
            maxLength={40}
          />
          <button
            type="submit"
            className="name-prompt-btn"
            disabled={!name.trim() || saving}
          >
            {saving ? 'Saving…' : 'Let\'s go'}
          </button>
        </form>
      </div>
    </div>
  );
}

function AuthPrompt() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        // Store the name in the session after sign-up creates it
        if (data.user && name.trim()) {
          // Session row is created by loadSession; store name in user metadata for now
          await supabase.auth.updateUser({ data: { display_name: name.trim() } });
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err: any) {
      setError(err.message);
    }
    setLoading(false);
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '10px 12px',
    border: '1px solid var(--line)',
    borderRadius: '12px',
    background: 'transparent',
    fontSize: '0.95rem',
    outline: 'none',
    boxSizing: 'border-box',
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    marginBottom: '6px',
    fontSize: '0.88rem',
    color: 'var(--muted)',
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--bg)',
        padding: '20px',
      }}
    >
      <div style={{ maxWidth: '400px', width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <div style={{ margin: '0 auto 14px', width: 56, height: 56 }}>
            <CamrynOrb size={56} />
          </div>
          <h1 style={{ margin: '0 0 8px', fontSize: '2rem', fontFamily: 'var(--font-display)' }}>
            Camryn
          </h1>
          <p style={{ margin: '0', color: 'var(--muted)', fontSize: '0.95rem' }}>
            Daily wellness protocol
          </p>
        </div>

        <form onSubmit={handleAuth} style={{ display: 'grid', gap: '12px' }}>
          {isSignUp && (
            <div>
              <label style={labelStyle}>Your first name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                style={inputStyle}
                placeholder="e.g. Jess"
                maxLength={40}
              />
            </div>
          )}
          <div>
            <label style={labelStyle}>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={inputStyle}
              required
            />
          </div>
          <div>
            <label style={labelStyle}>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={inputStyle}
              required
            />
          </div>

          {error && (
            <div style={{ padding: '10px', background: 'var(--accent-soft)', color: 'var(--accent)', borderRadius: '8px', fontSize: '0.9rem' }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              padding: '10px',
              border: '1px solid var(--ink)',
              borderRadius: '999px',
              background: 'transparent',
              color: 'var(--ink)',
              fontWeight: 700,
              cursor: 'pointer',
              marginTop: '8px',
            }}
          >
            {loading ? 'Loading...' : isSignUp ? 'Create account' : 'Sign in'}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '16px' }}>
          <button
            type="button"
            onClick={() => { setIsSignUp(!isSignUp); setError(''); }}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--muted)',
              cursor: 'pointer',
              fontSize: '0.9rem',
              textDecoration: 'underline',
            }}
          >
            {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
