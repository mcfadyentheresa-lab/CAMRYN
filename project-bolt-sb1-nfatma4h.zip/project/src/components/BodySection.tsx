import { useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import { VITAMINS } from '../lib/constants';
import { CYCLE_PHASES, cyclePhaseFromName } from '../lib/protocol';
import { useSaveIndicator } from '../hooks/useSaveIndicator';
import CheckIcon from './ui/CheckIcon';
import SaveIndicator from './ui/SaveIndicator';
import CycleLearnModal from './CycleLearnModal';

const today = new Date().toISOString().split('T')[0];

const CYCLE_STATUSES = [
  'Period day',
  'Post-period',
  'Ovulation-ish',
  'Luteal / PMS-ish',
  'Not sure',
];

interface BodyEntry {
  weight: string;
  energy: number | null;
  symptoms: string;
  vitamins: Record<string, boolean>;
  cycle_status: string;
  cycle_note: string;
}

const EMPTY: BodyEntry = {
  weight: '',
  energy: null,
  symptoms: '',
  vitamins: {},
  cycle_status: '',
  cycle_note: '',
};

interface BodySectionProps {
  userId: string;
  cyclePhase?: string;
  cycleDay?: number | null;
  lastPeriodDate?: string | null;
  onCyclePhaseChange?: (name: string) => void;
  onCycleDateChange?: (dateStr: string) => void;
}

export default function BodySection({
  userId,
  cyclePhase = 'Not sure',
  cycleDay,
  lastPeriodDate,
  onCyclePhaseChange,
  onCycleDateChange,
}: BodySectionProps) {
  const [entry, setEntry] = useState<BodyEntry>(EMPTY);
  const [saveLabel, startSave, doneSave] = useSaveIndicator();
  const pendingRef = useRef<BodyEntry>(EMPTY);
  const [showCycleLearning, setShowCycleLearning] = useState(false);
  const [showDateInput, setShowDateInput] = useState(!!lastPeriodDate);

  const cyclePhaseInfo = cyclePhaseFromName(cyclePhase);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('camryn_body')
        .select('weight, energy, symptoms, vitamins, cycle_status, cycle_note')
        .eq('user_id', userId)
        .eq('entry_date', today)
        .maybeSingle();

      if (data) {
        setEntry({
          weight: data.weight != null ? String(data.weight) : '',
          energy: data.energy ?? null,
          symptoms: data.symptoms || '',
          vitamins: (data.vitamins as Record<string, boolean>) || {},
          cycle_status: data.cycle_status || '',
          cycle_note: data.cycle_note || '',
        });
      }
    };

    load();
  }, [userId]);

  const persist = async (e: BodyEntry) => {
    startSave();
    await supabase.from('camryn_body').upsert(
      {
        user_id: userId,
        entry_date: today,
        weight: e.weight !== '' ? parseFloat(e.weight) : null,
        energy: e.energy,
        symptoms: e.symptoms,
        vitamins: e.vitamins,
        cycle_status: e.cycle_status,
        cycle_note: e.cycle_note,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'user_id,entry_date' }
    );
    doneSave();
  };

  const update = (patch: Partial<BodyEntry>) => {
    const next = { ...entry, ...patch };
    setEntry(next);
    pendingRef.current = next;
  };

  const handleBlur = () => persist(pendingRef.current);

  const [tappedVitamin, setTappedVitamin] = useState<string | null>(null);

  const toggleVitamin = (id: string) => {
    const next = { ...entry, vitamins: { ...entry.vitamins, [id]: !entry.vitamins[id] } };
    setEntry(next);
    pendingRef.current = next;
    persist(next);
    if (!entry.vitamins[id]) {
      setTappedVitamin(id);
      setTimeout(() => setTappedVitamin(null), 400);
    }
  };

  const selectCycleStatus = (status: string) => {
    const next = { ...entry, cycle_status: entry.cycle_status === status ? '' : status };
    setEntry(next);
    pendingRef.current = next;
    persist(next);
  };

  return (
    <section className="body-section">
      <div className="body-section-head">
        <div className="card-label" style={{ marginBottom: '2px' }}>Body</div>
        <h2 className="body-section-title">What your body is doing today</h2>
        <p className="body-section-sub">
          Weight, energy, cycle status, and vitamins — tracked quietly to support the protocol over time. All fields are optional.
        </p>
      </div>

      {/* ── Cycle phase card ── */}
      {onCyclePhaseChange && (
        <div className="cycle-card" style={{ marginBottom: '20px' }}>
          <div className="cycle-label">Cycle phase</div>
          {cycleDay && <div className="cycle-day-badge">Day {cycleDay}</div>}
          <div className="cycle-phase-name">{cyclePhaseInfo.name}</div>
          <div className="cycle-phase-desc">{cyclePhaseInfo.desc}</div>

          {showDateInput ? (
            <>
              <div className="cycle-input-label">First day of last period</div>
              <input
                type="date"
                className="cycle-date-input"
                value={lastPeriodDate || ''}
                onChange={(e) => onCycleDateChange?.(e.target.value)}
              />
              <button
                className="cycle-phase-btn"
                style={{ marginTop: '4px', fontSize: '0.78rem' }}
                onClick={() => setShowDateInput(false)}
              >
                Set phase manually instead
              </button>
            </>
          ) : (
            <>
              <div className="cycle-phase-buttons">
                {CYCLE_PHASES.filter((p) => p.name !== 'Not sure').map((p) => (
                  <button
                    key={p.name}
                    className={`cycle-phase-btn ${p.name === cyclePhase ? 'active' : ''}`}
                    onClick={() => onCyclePhaseChange(p.name)}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
              <button
                className="cycle-phase-btn"
                style={{ marginTop: '8px', fontSize: '0.78rem' }}
                onClick={() => setShowDateInput(true)}
              >
                Use period date instead
              </button>
            </>
          )}

          <button className="cycle-learn-btn" onClick={() => setShowCycleLearning(true)}>
            Learn about your phase →
          </button>

          {showCycleLearning && (
            <CycleLearnModal
              phaseName={cyclePhase}
              onClose={() => setShowCycleLearning(false)}
            />
          )}
        </div>
      )}

      <div className="body-grid">
        {/* Card 1 — Today's body snapshot */}
        <div className="body-card">
          <div className="body-card-header">
            <h3 className="body-card-title">Today's body snapshot</h3>
            <span className="body-pill">Body data</span>
          </div>

          <div className="body-field">
            <label className="field-label" htmlFor="body-weight">
              Weight <span className="body-optional">(optional)</span>
            </label>
            <input
              id="body-weight"
              type="number"
              step="0.1"
              className="body-input"
              value={entry.weight}
              onChange={(e) => update({ weight: e.target.value })}
              onBlur={handleBlur}
              placeholder="e.g. 145.2"
            />
          </div>

          <div className="body-field">
            <label className="field-label">
              Body energy <span className="body-optional">(optional — separate from today's protocol check-in)</span>
            </label>
            <div className="energy-row">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  className={`energy-dot ${entry.energy === n ? 'active' : ''}`}
                  onClick={() => {
                    const next = { ...entry, energy: entry.energy === n ? null : n };
                    setEntry(next);
                    pendingRef.current = next;
                    persist(next);
                  }}
                  aria-label={`Energy ${n}`}
                >
                  {n}
                </button>
              ))}
              <span className="energy-label">
                {entry.energy === null ? '' :
                 entry.energy <= 2 ? 'Low' :
                 entry.energy === 3 ? 'Okay' : 'Good'}
              </span>
            </div>
          </div>

          <div className="body-field">
            <label className="field-label" htmlFor="body-symptoms">
              Hormone / body symptoms <span className="body-optional">(optional)</span>
            </label>
            <textarea
              id="body-symptoms"
              className="body-textarea"
              value={entry.symptoms}
              onChange={(e) => update({ symptoms: e.target.value })}
              onBlur={handleBlur}
              placeholder="Cramping, bloating, tenderness, anxiety, vivid dreams, etc."
            />
          </div>
        </div>

        {/* Card 2 — Vitamins & cycle */}
        <div className="body-card">
          <div className="body-card-header">
            <h3 className="body-card-title">Vitamins &amp; cycle</h3>
            <span className="body-pill teal">Supplements</span>
          </div>

          <div className="body-field">
            <div className="field-label" style={{ marginBottom: '8px' }}>
              Taken today <span className="body-optional">(tap to mark)</span>
            </div>
            <div className="vitamin-grid">
              {VITAMINS.map((v) => (
                <button
                  key={v.id}
                  className={`vitamin-btn ${entry.vitamins[v.id] ? 'checked' : ''} ${tappedVitamin === v.id ? 'vitamin-pop' : ''}`}
                  onClick={() => toggleVitamin(v.id)}
                >
                  <span className="vitamin-check">
                    {entry.vitamins[v.id] && <CheckIcon />}
                  </span>
                  {v.label}
                </button>
              ))}
            </div>
          </div>

          <div className="body-field">
            <div className="field-label" style={{ marginBottom: '8px' }}>
              Cycle status <span className="body-optional">(optional)</span>
            </div>
            <div className="cycle-status-row">
              {CYCLE_STATUSES.map((s) => (
                <button
                  key={s}
                  className={`seg-btn ${entry.cycle_status === s ? 'active' : ''}`}
                  onClick={() => selectCycleStatus(s)}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="body-field">
            <label className="field-label" htmlFor="body-cycle-note">
              Cycle note <span className="body-optional">(optional)</span>
            </label>
            <textarea
              id="body-cycle-note"
              className="body-textarea"
              value={entry.cycle_note}
              onChange={(e) => update({ cycle_note: e.target.value })}
              onBlur={handleBlur}
              placeholder="Day 2, medium flow, craving salt — whatever feels worth noting."
            />
          </div>
        </div>
      </div>

      <SaveIndicator state={saveLabel} className="body-save-indicator" />
    </section>
  );
}
