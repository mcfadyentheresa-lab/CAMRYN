import { useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useSaveIndicator } from '../hooks/useSaveIndicator';
import SaveIndicator from './ui/SaveIndicator';

const today = new Date().toISOString().split('T')[0];

// ── Stylist questions ──────────────────────────────────────────────────────
const STYLIST_QUESTIONS = [
  {
    id: 'style_words' as const,
    prompt: 'Three words for how you want to look when you walk into a room.',
    placeholder: 'e.g. soft, competent, a little dangerous',
  },
  {
    id: 'lifestyle_context' as const,
    prompt: 'Where do you actually spend most of your week?',
    placeholder: 'e.g. school drop-offs, office two days, errands, couch at night',
  },
  {
    id: 'body_fit_dread' as const,
    prompt: 'One thing about getting dressed that you secretly dread.',
    placeholder: 'e.g. tight waistbands by 3pm, nothing fitting at the shoulder',
  },
  {
    id: 'closet_best_outfit' as const,
    prompt: 'Describe an outfit you reached for on a day you felt most like yourself.',
    placeholder: 'e.g. black wide-leg pants, white tee, leather jacket, gold hoops',
  },
  {
    id: 'closet_skip_piece' as const,
    prompt: "Name one piece you always skip and don't know why.",
    placeholder: "e.g. pink blazer I thought I should want but never wear",
  },
  {
    id: 'signal_wish' as const,
    prompt: 'What do you wish people sensed about you before you spoke?',
    placeholder: "e.g. that I'm warm and capable, not just tired or messy",
  },
  {
    id: 'style_influence' as const,
    prompt: "If you could borrow anyone's wardrobe for a month, whose would it be and why?",
    placeholder: 'e.g. Sade — polished but not stiff, always looks like herself',
  },
] as const;

type ProfileKey = typeof STYLIST_QUESTIONS[number]['id'];
type Profile = Record<ProfileKey, string>;

const EMPTY_PROFILE: Profile = {
  style_words: '',
  lifestyle_context: '',
  body_fit_dread: '',
  closet_best_outfit: '',
  closet_skip_piece: '',
  signal_wish: '',
  style_influence: '',
};

// ── Milestone logic ────────────────────────────────────────────────────────
const MAX_SCORE = 9; // 7 questions + 1 (3 days) + 1 (10 days)

function computeMilestone(profile: Profile, confDays: number): { score: number; label: string } {
  const answered = Object.values(profile).filter(v => v.trim().length > 0).length;
  const dailyPts = confDays >= 10 ? 2 : confDays >= 3 ? 1 : 0;
  const score = answered + dailyPts;

  let label = 'Just starting to remeet yourself.';
  if (score >= 6)      label = "You've given Camryn enough to act like your quiet stylist.";
  else if (score >= 4) label = "Camryn has a real feel for your style and confidence patterns.";
  else if (score >= 2) label = "You're getting to know how you like to show up.";

  return { score, label };
}

// ── Component ─────────────────────────────────────────────────────────────
interface ConfidenceSectionProps {
  userId: string;
}

export default function ConfidenceSection({ userId }: ConfidenceSectionProps) {
  // Daily state
  const [confNote, setConfNote] = useState('');
  const [rebrandNote, setRebrandNote] = useState('');
  const dailyPending = useRef({ confidence_note: '', rebrand_note: '' });
  const [dailySave, startDailySave, doneDailySave] = useSaveIndicator();

  // Profile state
  const [profile, setProfile] = useState<Profile>(EMPTY_PROFILE);
  const profilePending = useRef<Profile>(EMPTY_PROFILE);
  const [profileSave, startProfileSave, doneProfileSave] = useSaveIndicator();
  const [justSavedId, setJustSavedId] = useState<ProfileKey | null>(null);

  // Metadata
  const [confDays, setConfDays] = useState(0);
  const [questionsOpen, setQuestionsOpen] = useState(false);

  // ── Load ──────────────────────────────────────────────────────────────
  useEffect(() => {
    const load = async () => {
      const [dailyRes, profileRes, daysRes] = await Promise.all([
        supabase
          .from('camryn_confidence')
          .select('confidence_note, rebrand_note')
          .eq('user_id', userId)
          .eq('entry_date', today)
          .maybeSingle(),
        supabase
          .from('camryn_confidence_profile')
          .select('style_words, lifestyle_context, body_fit_dread, closet_best_outfit, closet_skip_piece, signal_wish, style_influence')
          .eq('user_id', userId)
          .maybeSingle(),
        supabase
          .from('camryn_confidence')
          .select('entry_date', { count: 'exact', head: true })
          .eq('user_id', userId)
          .neq('confidence_note', ''),
      ]);

      if (dailyRes.data) {
        const cn = dailyRes.data.confidence_note || '';
        const rn = dailyRes.data.rebrand_note || '';
        setConfNote(cn);
        setRebrandNote(rn);
        dailyPending.current = { confidence_note: cn, rebrand_note: rn };
      }

      if (profileRes.data) {
        const p: Profile = {
          style_words:        profileRes.data.style_words        || '',
          lifestyle_context:  profileRes.data.lifestyle_context  || '',
          body_fit_dread:     profileRes.data.body_fit_dread     || '',
          closet_best_outfit: profileRes.data.closet_best_outfit || '',
          closet_skip_piece:  profileRes.data.closet_skip_piece  || '',
          signal_wish:        profileRes.data.signal_wish        || '',
          style_influence:    profileRes.data.style_influence    || '',
        };
        setProfile(p);
        profilePending.current = p;
      }

      setConfDays(daysRes.count || 0);
    };

    load();
  }, [userId]);

  // ── Daily save ────────────────────────────────────────────────────────
  const saveDaily = async () => {
    startDailySave();
    await supabase.from('camryn_confidence').upsert(
      {
        user_id: userId,
        entry_date: today,
        confidence_note: dailyPending.current.confidence_note,
        rebrand_note:    dailyPending.current.rebrand_note,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'user_id,entry_date' }
    );
    doneDailySave();
    if (dailyPending.current.confidence_note.trim()) {
      setConfDays(d => Math.max(d, 1));
    }
  };

  // ── Profile save ──────────────────────────────────────────────────────
  const saveProfile = async (savedId?: ProfileKey) => {
    startProfileSave();
    await supabase.from('camryn_confidence_profile').upsert(
      {
        user_id: userId,
        ...profilePending.current,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'user_id' }
    );
    doneProfileSave();
    if (savedId) {
      setJustSavedId(savedId);
      setTimeout(() => setJustSavedId(null), 2000);
    }
  };

  // ── Milestone ─────────────────────────────────────────────────────────
  const { score, label } = computeMilestone(profile, confDays);
  const pct = Math.min((score / MAX_SCORE) * 100, 100);
  const answeredCount = Object.values(profile).filter(v => v.trim().length > 0).length;

  return (
    <section className="conf-section">

      {/* Header */}
      <div className="conf-head">
        <div className="card-label" style={{ marginBottom: '2px' }}>Confidence</div>
        <h2 className="conf-title">How you show up</h2>
        <p className="conf-sub">
          This lane follows you through every phase — collecting how you present yourself daily and the deeper style patterns that make you recognisably you.
        </p>
      </div>

      {/* Progress scale */}
      <div className="conf-progress-card">
        <div className="conf-progress-header">
          <span className="conf-progress-label">Confidence profile</span>
          <span className="conf-progress-count">
            {answeredCount} of {STYLIST_QUESTIONS.length} questions
          </span>
        </div>
        <div className="conf-progress-track">
          <div className="conf-progress-fill" style={{ width: `${pct}%` }} />
        </div>
        <p className="conf-progress-caption">{label}</p>
      </div>

      {/* Daily snapshot */}
      <div className="conf-card">
        <div className="conf-card-header">
          <h3 className="conf-card-title">Today's confidence snapshot</h3>
          <span className="conf-pill">Daily</span>
        </div>
        <p className="conf-card-intro">On the outside, how did you present yourself today?</p>
        <ul className="conf-anchors">
          <li>Clothes and shoes</li>
          <li>Hair, face, scent</li>
          <li>Any tiny upgrade you made for yourself</li>
        </ul>
        <textarea
          id="confidence-note"
          className="conf-textarea"
          value={confNote}
          onChange={e => { setConfNote(e.target.value); dailyPending.current.confidence_note = e.target.value; }}
          onBlur={saveDaily}
          placeholder="One detail that made you feel a little more confident, or one thing that felt off."
        />

        <div className="conf-divider" />

        <div className="conf-rebrand-header">
          <span className="conf-rebrand-label">Rebrand notes</span>
          <span className="conf-pill teal">Keep / retire</span>
        </div>
        <p className="conf-card-intro" style={{ marginBottom: '6px' }}>
          What are you keeping, retiring, or reconsidering? Filed quietly into your rebrand profile.
        </p>
        <textarea
          id="rebrand-note"
          className="conf-textarea"
          value={rebrandNote}
          onChange={e => { setRebrandNote(e.target.value); dailyPending.current.rebrand_note = e.target.value; }}
          onBlur={saveDaily}
          placeholder="e.g. retiring the chunky sneakers, keeping the gold hoops, want to try a blowout."
        />

        <SaveIndicator state={dailySave} className="conf-save-indicator" />
      </div>

      {/* Stylist questions */}
      <div className="conf-card conf-questions-card">
        <button
          className="conf-questions-toggle"
          onClick={() => setQuestionsOpen(o => !o)}
          aria-expanded={questionsOpen}
        >
          <div>
            <h3 className="conf-card-title">Reintroducing yourself</h3>
            <p className="conf-card-intro">
              Questions a good stylist would ask over coffee, answered slowly over time.
            </p>
          </div>
          <div className={`conf-chevron ${questionsOpen ? 'open' : ''}`}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M3 5L7 9L11 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </button>

        {questionsOpen && (
          <div className="conf-questions-body">
            <p className="conf-questions-intro">
              There's no rush. Answer what feels easy first. Every answer gives Camryn a clearer picture of your style.
            </p>
            <div className="conf-questions-list">
              {STYLIST_QUESTIONS.map((q, idx) => {
                const val = profile[q.id];
                const filled = val.trim().length > 0;
                return (
                  <div key={q.id} className={`conf-q-item ${filled ? 'answered' : ''}`}>
                    <div className="conf-q-meta">
                      <span className="conf-q-num">{idx + 1}</span>
                      {filled && <span className="conf-q-dot" aria-label="answered" />}
                    </div>
                    <div className="conf-q-body">
                      <label className="conf-q-prompt" htmlFor={`sq-${q.id}`}>{q.prompt}</label>
                      <textarea
                        id={`sq-${q.id}`}
                        className="conf-textarea"
                        value={val}
                        onChange={e => {
                          const next = { ...profile, [q.id]: e.target.value };
                          setProfile(next);
                          profilePending.current = next;
                        }}
                        onBlur={() => saveProfile(q.id)}
                        placeholder={q.placeholder}
                      />
                      {justSavedId === q.id && profileSave !== 'idle' && (
                        <span className="conf-q-saved">Saved</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
