import { useState } from 'react';
import ProtocolModal from './ProtocolModal';
import CamrynAvatar from './ui/CamrynAvatar';

export type AppView = 'today' | 'body' | 'confidence' | 'space' | 'journal' | 'profile';

const NAV_LANES: { id: AppView; label: string }[] = [
  { id: 'today',      label: 'Today' },
  { id: 'body',       label: 'Body' },
  { id: 'confidence', label: 'Confidence' },
  { id: 'space',      label: 'Space' },
  { id: 'journal',    label: 'Journal' },
  { id: 'profile',    label: 'Profile' },
];

interface HeaderProps {
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
  saveStatus: string;
  onSignOut: () => void;
  view: AppView;
  onViewChange: (view: AppView) => void;
  currentPhase?: number;
  displayName?: string | null;
}

export default function Header({ theme, onThemeToggle, saveStatus, onSignOut, view, onViewChange, currentPhase, displayName }: HeaderProps) {
  const [showProtocol, setShowProtocol] = useState(false);

  return (
    <>
      <nav className="topnav">
        {/* Row 1: brand + actions */}
        <div className="topnav-bar">
          <div className="brand">
            <div className="mark brand-avatar">
              <CamrynAvatar size={32} />
            </div>
            <div className="brand-text">
              <span className="brand-name">Camryn</span>
              {displayName && (
                <span className="brand-greeting">Hi, {displayName}</span>
              )}
            </div>
          </div>

          <div className="nav-actions">
            <span className="save-status">{saveStatus}</span>
            <button className="nav-btn" onClick={() => setShowProtocol(true)}>Protocol</button>
            <button className="nav-btn" onClick={onThemeToggle}>{theme === 'light' ? 'Dark' : 'Light'}</button>
            <button className="nav-btn" onClick={onSignOut}>Sign out</button>
          </div>
        </div>

        {/* Row 2: scrollable lane tabs */}
        <div className="nav-lanes-wrap">
          <div className="nav-lanes">
            {NAV_LANES.map(lane => (
              <button
                key={lane.id}
                className={`nav-lane-btn ${view === lane.id ? 'active' : ''}`}
                onClick={() => onViewChange(lane.id)}
              >
                {lane.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {showProtocol && <ProtocolModal onClose={() => setShowProtocol(false)} currentPhase={currentPhase} />}
    </>
  );
}
