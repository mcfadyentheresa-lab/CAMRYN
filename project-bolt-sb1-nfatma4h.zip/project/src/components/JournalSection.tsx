import { useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import { loadMasteryData, calcStreak, FOUNDATION_QUESTS } from '../lib/mastery';
import { getIntentionalAction } from '../lib/cycleActions';
import CamrynAvatar from './ui/CamrynAvatar';

interface JournalEntry {
  id: string;
  created_at: string;
  entry_date: string;
  user_text: string;
  camryn_reply: string;
  phase: string;
  protocol_phase: number;
  energy: string;
  body_snapshot: Record<string, any>;
  confidence_snapshot: Record<string, any>;
  mastery_snapshot: Record<string, any>;
}

interface ConversationTurn {
  role: 'user' | 'assistant';
  content: string;
}

interface Session {
  current_phase: number;
  cycle_phase_name: string;
  energy: string;
}

interface JournalSectionProps {
  userId: string;
  session: Session;
  focusInput?: boolean;
  displayName?: string | null;
}

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

async function fetchBodySnapshot(userId: string): Promise<Record<string, any>> {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('camryn_body')
    .select('energy, symptoms, cycle_status, vitamins')
    .eq('user_id', userId)
    .eq('entry_date', today)
    .maybeSingle();
  return data ?? {};
}

async function fetchConfidenceSnapshot(userId: string): Promise<Record<string, any>> {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('camryn_confidence')
    .select('confidence_note')
    .eq('user_id', userId)
    .eq('entry_date', today)
    .maybeSingle();
  return data ?? {};
}

function buildMasterySnapshot(): Record<string, number> {
  const masteryData = loadMasteryData();
  const snapshot: Record<string, number> = {};
  for (const q of FOUNDATION_QUESTS) {
    const qs = masteryData.quests[q.id];
    if (!qs) continue;
    const streak = calcStreak(qs.completedDates, qs.targetDays);
    if (streak > 0) snapshot[q.title] = streak;
  }
  return snapshot;
}

function buildHistory(todayEntries: JournalEntry[]): ConversationTurn[] {
  // Build ordered history from oldest to newest, max last 6 exchanges (12 turns)
  const ordered = [...todayEntries].sort(
    (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
  );
  const recent = ordered.slice(-6);
  const turns: ConversationTurn[] = [];
  for (const e of recent) {
    turns.push({ role: 'user', content: e.user_text });
    if (e.camryn_reply) turns.push({ role: 'assistant', content: e.camryn_reply });
  }
  return turns;
}

// Group entries by date for the list view
function groupByDate(entries: JournalEntry[]): Map<string, JournalEntry[]> {
  const map = new Map<string, JournalEntry[]>();
  for (const e of entries) {
    const d = e.entry_date;
    if (!map.has(d)) map.set(d, []);
    map.get(d)!.push(e);
  }
  return map;
}

export default function JournalSection({ userId, session, focusInput, displayName }: JournalSectionProps) {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [loadingEntries, setLoadingEntries] = useState(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const today = new Date().toISOString().split('T')[0];
  const todayEntries = entries.filter((e) => e.entry_date === today);
  const pastEntries = entries.filter((e) => e.entry_date !== today);

  useEffect(() => {
    loadEntries();
  }, [userId]);

  useEffect(() => {
    if (focusInput && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [focusInput]);

  // Scroll to bottom of today's thread when new messages arrive
  useEffect(() => {
    if (todayEntries.length > 0) {
      setTimeout(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
      }, 80);
    }
  }, [todayEntries.length]);

  const loadEntries = async () => {
    setLoadingEntries(true);
    const { data } = await supabase
      .from('camryn_journal')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: true })
      .limit(100);
    setEntries((data as JournalEntry[]) ?? []);
    setLoadingEntries(false);
  };

  const handleSend = async () => {
    const trimmed = text.trim();
    if (!trimmed || sending) return;

    setSending(true);

    const [bodySnapshot, confidenceSnapshot] = await Promise.all([
      fetchBodySnapshot(userId),
      fetchConfidenceSnapshot(userId),
    ]);
    const masterySnapshot = buildMasterySnapshot();
    const intentional = getIntentionalAction();
    const history = buildHistory(todayEntries);

    let camrynReply = '';
    try {
      const resp = await fetch(`${SUPABASE_URL}/functions/v1/camryn-journal`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userText: trimmed,
          cyclePhase: session.cycle_phase_name,
          protocolPhase: session.current_phase,
          energy: session.energy,
          bodySnapshot,
          confidenceSnapshot,
          masterySnapshot,
          intentionalAction: intentional?.text ?? '',
          history,
          userName: displayName ?? null,
        }),
      });
      if (resp.ok) {
        const json = await resp.json();
        camrynReply = json.reply ?? '';
      } else {
        camrynReply = "Camryn had trouble responding just now, but your entry is saved. Try again in a bit.";
      }
    } catch {
      camrynReply = "Camryn had trouble responding just now, but your entry is saved. Try again in a bit.";
    }

    const { data: saved } = await supabase
      .from('camryn_journal')
      .insert([{
        user_id: userId,
        entry_date: today,
        user_text: trimmed,
        camryn_reply: camrynReply,
        phase: session.cycle_phase_name,
        protocol_phase: session.current_phase,
        energy: session.energy,
        body_snapshot: bodySnapshot,
        confidence_snapshot: confidenceSnapshot,
        mastery_snapshot: masterySnapshot,
      }])
      .select()
      .maybeSingle();

    if (saved) {
      setEntries((prev) => [...prev, saved as JournalEntry]);
    }

    setText('');
    setSending(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSend();
    }
  };

  const autoResize = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  };

  const pastGroups = groupByDate(pastEntries);

  return (
    <div className="journal-section">
      {/* Header */}
      <div className="journal-header">
        <div className="journal-header-inner">
          <CamrynAvatar size={48} className="journal-header-avatar" />
          <div>
            <div className="card-label" style={{ marginBottom: '4px' }}>Reflect</div>
            <h2 className="journal-title">
              {displayName ? `${displayName}'s journal` : 'Journal with Camryn'}
            </h2>
            <p className="journal-subtitle">
              Talk through your day. Camryn remembers what you've shared and follows the thread.
            </p>
          </div>
        </div>
      </div>

      {loadingEntries ? (
        <div className="journal-empty">Loading your journal…</div>
      ) : (
        <div className="journal-chat-wrap">

          {/* Past days collapsed */}
          {pastGroups.size > 0 && (
            <div className="journal-past-days">
              {Array.from(pastGroups.entries())
                .sort(([a], [b]) => a.localeCompare(b))
                .map(([date, dayEntries]) => (
                  <PastDayThread key={date} date={date} entries={dayEntries} />
                ))}
            </div>
          )}

          {/* Today's thread */}
          <div className="journal-today-thread">
            {todayEntries.length === 0 && (
              <div className="journal-empty-today">
                <p>Start the conversation — what did today feel like?</p>
                <p className="journal-empty-sub">Your body, your mind, what was easy or hard. Camryn listens and follows up.</p>
              </div>
            )}

            {todayEntries.map((entry, i) => (
              <div key={entry.id} className="journal-turn">
                {i === 0 && (
                  <div className="journal-date-divider">
                    <span>Today · {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</span>
                  </div>
                )}

                {/* User bubble */}
                <div className="journal-bubble-row user">
                  <div className="journal-bubble user-bubble">
                    {entry.user_text}
                    <span className="journal-bubble-time">{formatTime(entry.created_at)}</span>
                  </div>
                </div>

                {/* Camryn bubble */}
                {entry.camryn_reply && (
                  <div className="journal-bubble-row camryn">
                    <CamrynAvatar size={28} className="journal-avatar-img" />
                    <div className="journal-bubble camryn-bubble">
                      {entry.camryn_reply.split('\n\n').map((para, pi) => (
                        <p key={pi}>{para}</p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Typing indicator while sending */}
            {sending && (
              <div className="journal-bubble-row camryn">
                <CamrynAvatar size={28} className="journal-avatar-img" />
                <div className="journal-bubble camryn-bubble journal-typing">
                  <span /><span /><span />
                </div>
              </div>
            )}

            <div ref={bottomRef} />
          </div>
        </div>
      )}

      {/* Sticky input */}
      <div className="journal-input-dock">
        <textarea
          ref={textareaRef}
          className="journal-textarea"
          rows={1}
          value={text}
          onChange={autoResize}
          onKeyDown={handleKeyDown}
          placeholder={todayEntries.length > 0 ? 'Continue the conversation…' : 'What did today feel like in your body, mind, and how you showed up?'}
          disabled={sending}
        />
        <div className="journal-input-footer">
          <span className="journal-hint">⌘ Return to send</span>
          <button
            className={`journal-send-btn ${sending ? 'loading' : ''}`}
            onClick={handleSend}
            disabled={!text.trim() || sending}
          >
            {sending ? <span className="journal-send-spinner" /> : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );
}

function PastDayThread({ date, entries }: { date: string; entries: JournalEntry[] }) {
  const [open, setOpen] = useState(false);
  const label = new Date(date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <div className="journal-past-day">
      <button className="journal-past-toggle" onClick={() => setOpen((v) => !v)}>
        <svg
          className={`journal-past-chevron ${open ? 'open' : ''}`}
          width="12" height="12" viewBox="0 0 12 12" fill="none"
        >
          <path d="M2.5 4.5l3.5 3.5 3.5-3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span>{label}</span>
        <span className="journal-past-count">{entries.length} {entries.length === 1 ? 'exchange' : 'exchanges'}</span>
      </button>

      {open && (
        <div className="journal-past-thread">
          {entries.map((entry) => (
            <div key={entry.id} className="journal-turn">
              <div className="journal-bubble-row user">
                <div className="journal-bubble user-bubble">
                  {entry.user_text}
                  <span className="journal-bubble-time">{new Date(entry.created_at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span>
                </div>
              </div>
              {entry.camryn_reply && (
                <div className="journal-bubble-row camryn">
                  <CamrynAvatar size={28} className="journal-avatar-img" />
                  <div className="journal-bubble camryn-bubble">
                    {entry.camryn_reply.split('\n\n').map((para, pi) => (
                      <p key={pi}>{para}</p>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
