import { useState, useEffect } from 'react';
import { dailyLearnForToday } from '../lib/protocol';

interface Props {
  cyclePhaseName: string;
}

const STORAGE_KEY = 'camryn_learn_dismissed';

export default function DailyLearnCard({ cyclePhaseName }: Props) {
  const [visible, setVisible] = useState(false);
  const [animating, setAnimating] = useState(false);

  const learn = dailyLearnForToday(cyclePhaseName);
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    const dismissed = localStorage.getItem(STORAGE_KEY);
    if (dismissed !== today) {
      const timer = setTimeout(() => {
        setVisible(true);
        requestAnimationFrame(() => requestAnimationFrame(() => setAnimating(true)));
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [today]);

  const dismiss = () => {
    setAnimating(false);
    setTimeout(() => {
      setVisible(false);
      localStorage.setItem(STORAGE_KEY, today);
    }, 280);
  };

  if (!visible) return null;

  return (
    <div
      className={`daily-learn-backdrop ${animating ? 'visible' : ''}`}
      onClick={dismiss}
    >
      <div
        className={`daily-learn-card ${animating ? 'visible' : ''}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="daily-learn-tag">{learn.tag} · Today's insight</div>
        <h3 className="daily-learn-title">{learn.title}</h3>
        <p className="daily-learn-body">{learn.body}</p>
        <button className="daily-learn-close" onClick={dismiss} aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M1 1l12 12M13 1L1 13" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
