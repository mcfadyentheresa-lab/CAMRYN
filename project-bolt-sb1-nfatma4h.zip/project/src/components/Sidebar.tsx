import { useState } from 'react';
import { CYCLE_PHASES, cyclePhaseFromName } from '../lib/protocol';
import CycleLearnModal from './CycleLearnModal';

interface Session {
  current_phase: number;
  cycle_phase_name: string;
  cycle_day: number | null;
  last_period_date: string | null;
  energy: string;
}

interface Unlock {
  status: string;
  remaining_days: number;
  total_days: number;
  title: string;
}

interface SidebarProps {
  session: Session;
  unlocks: Unlock[];
  onCycleDateChange: (dateStr: string) => void;
  onPhaseChange?: (phase: number) => void;
  onCyclePhaseChange: (name: string) => void;
}

export default function Sidebar({
  session,
  onCycleDateChange,
  onCyclePhaseChange,
}: SidebarProps) {
  const [showCycleLearning, setShowCycleLearning] = useState(false);
  const [showDateInput, setShowDateInput] = useState(!!session.last_period_date);

  const cyclePhase = cyclePhaseFromName(session.cycle_phase_name);

  return (
    <>
      <div className="cycle-card">
        <div className="cycle-label">Cycle phase</div>

        {session.cycle_day && (
          <div className="cycle-day-badge">Day {session.cycle_day}</div>
        )}

        <div className="cycle-phase-name">{cyclePhase.name}</div>
        <div className="cycle-phase-desc">{cyclePhase.desc}</div>

        {showDateInput ? (
          <>
            <div className="cycle-input-label">First day of last period</div>
            <input
              type="date"
              className="cycle-date-input"
              value={session.last_period_date || ''}
              onChange={(e) => onCycleDateChange(e.target.value)}
            />
            <button
              className="cycle-phase-btn"
              style={{ marginTop: '4px', fontSize: '0.78rem' }}
              onClick={() => setShowDateInput(false)}
            >
              Set phase manually instead
            </button>
          </>
        ) : (
          <>
            <div className="cycle-phase-buttons">
              {CYCLE_PHASES.filter((p) => p.name !== 'Not sure').map((phase) => (
                <button
                  key={phase.name}
                  className={`cycle-phase-btn ${phase.name === session.cycle_phase_name ? 'active' : ''}`}
                  onClick={() => onCyclePhaseChange(phase.name)}
                >
                  {phase.name}
                </button>
              ))}
            </div>
            <button
              className="cycle-phase-btn"
              style={{ marginTop: '8px', fontSize: '0.78rem' }}
              onClick={() => setShowDateInput(true)}
            >
              Use period date instead
            </button>
          </>
        )}

        <button className="cycle-learn-btn" onClick={() => setShowCycleLearning(true)}>
          Learn about your phase →
        </button>
      </div>

      {showCycleLearning && (
        <CycleLearnModal
          phaseName={session.cycle_phase_name}
          onClose={() => setShowCycleLearning(false)}
        />
      )}
    </>
  );
}
