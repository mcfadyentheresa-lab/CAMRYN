import { PROTOCOL } from '../lib/protocol';

interface ProtocolModalProps {
  onClose: () => void;
  currentPhase?: number;
}

export default function ProtocolModal({ onClose, currentPhase }: ProtocolModalProps) {
  return (
    <div
      className="modal-backdrop"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="modal-sheet">
        <div className="modal-header">
          <div>
            <h3 className="modal-title">The Camryn Protocol</h3>
            <p className="modal-subtitle">
              A 12-month transformation system designed around phases, cycle awareness, mastery, and daily emotional usability.
            </p>
          </div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        <div style={{ display: 'grid', gap: '12px' }}>
          {PROTOCOL.phases.map((phase) => {
            const isHere = phase.id === currentPhase;
            return (
              <div
                key={phase.id}
                style={{
                  padding: '16px',
                  background: isHere ? 'var(--accent-soft)' : 'var(--soft)',
                  borderRadius: '14px',
                  border: isHere ? '1.5px solid var(--accent-2)' : '1.5px solid transparent',
                  position: 'relative',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <div style={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: isHere ? 'var(--accent)' : 'var(--muted)' }}>
                    Phase {phase.id} · Weeks {phase.weeks}
                  </div>
                  {isHere && (
                    <span style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '5px',
                      fontSize: '0.7rem',
                      fontWeight: 700,
                      letterSpacing: '0.06em',
                      textTransform: 'uppercase',
                      color: 'var(--accent)',
                      background: 'var(--paper)',
                      border: '1px solid var(--accent-2)',
                      borderRadius: '999px',
                      padding: '3px 9px',
                    }}>
                      <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--accent)', display: 'inline-block' }} />
                      You are here
                    </span>
                  )}
                </div>
                <div style={{ fontWeight: 700, fontSize: '1rem', marginBottom: '3px', color: 'var(--ink)' }}>
                  {phase.name}
                </div>
                <div style={{ fontSize: '0.82rem', color: 'var(--muted)', marginBottom: '6px' }}>
                  {phase.focus}
                </div>
                <div style={{ fontSize: '0.84rem', color: 'var(--ink-2)', lineHeight: 1.5 }}>
                  {phase.promise}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
