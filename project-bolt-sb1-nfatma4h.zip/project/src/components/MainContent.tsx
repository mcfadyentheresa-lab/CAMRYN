import { useState, useCallback, useEffect } from 'react';
import { PROTOCOL, dailyTasks, taskTier } from '../lib/protocol';
import DailyLearnCard from './DailyLearnCard';
import {
  FOUNDATION_QUESTS,
  loadMasteryData,
  saveMasteryData,
  ensureDailyPick,
  calcStreak,
  isTodayCompleted,
  toggleToday,
  type MasteryData,
} from '../lib/mastery';
import MasteryCard from './MasteryCard';
import CycleActionTile from './CycleActionTile';

interface Session {
  current_phase: number;
  cycle_phase_name: string;
  cycle_day: number | null;
  last_period_date: string | null;
  energy: string;
  stress: string;
}

interface Unlock {
  id: string;
  status: string;
  remaining_days: number;
  total_days: number;
  title: string;
}

interface MainContentProps {
  session: Session;
  unlocks: Unlock[];
  onEnergyChange: (energy: string) => void;
  onStressChange: (stress: string) => void;
  onCyclePhaseChange: (name: string) => void;
  onCycleDateChange: (dateStr: string) => void;
  onSaveDay: (complete: number, total: number) => void;
  onNavigateToJournal?: () => void;
  onPhaseProgressChange?: (pct: number) => void;
}

function calcProgressPct(data: MasteryData): number {
  const totalTarget = FOUNDATION_QUESTS.reduce((acc, q) => acc + q.targetDays, 0);
  const totalEarned = FOUNDATION_QUESTS.reduce((acc, q) => {
    const qs = data.quests[q.id];
    if (!qs) return acc;
    return acc + Math.min(calcStreak(qs.completedDates, q.targetDays), q.targetDays);
  }, 0);
  return totalTarget > 0 ? Math.round((totalEarned / totalTarget) * 100) : 0;
}

function questIdFromTag(tag: string): string | null {
  if (tag.includes('Hydration'))       return 'morning-hydration';
  if (tag.includes('Sleep'))           return 'fixed-sleep';
  if (tag.includes('Gut'))             return 'fiber-goal';
  if (tag.includes('Self-Assessment')) return 'daily-checkin';
  if (tag.includes('Daily check-in'))  return 'daily-checkin';
  return null;
}

function initMastery(): MasteryData {
  const raw = loadMasteryData();
  const quests = { ...raw.quests };
  for (const q of FOUNDATION_QUESTS) {
    if (!quests[q.id]) quests[q.id] = { targetDays: q.targetDays, completedDates: [] };
  }
  const merged = ensureDailyPick({ ...raw, quests });
  saveMasteryData(merged);
  return merged;
}

export default function MainContent({
  session,
  unlocks: _unlocks,
  onEnergyChange,
  onStressChange,
  onCyclePhaseChange: _onCyclePhaseChange,
  onCycleDateChange: _onCycleDateChange,
  onSaveDay,
  onNavigateToJournal,
  onPhaseProgressChange,
}: MainContentProps) {
  const [checkedItems, setCheckedItems] = useState<boolean[]>([false, false, false]);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [masteryData, setMasteryData] = useState<MasteryData>(initMastery);
  const [highlightedQuestId, setHighlightedQuestId] = useState<string | null>(null);
  const [masteryOpen, setMasteryOpen] = useState(false);

  const phase = PROTOCOL.phases.find((p) => p.id === session.current_phase) || PROTOCOL.phases[0];
  const tier = taskTier(session.energy);
  const tasks = dailyTasks(session.current_phase, session.energy, session.stress, session.cycle_phase_name);
  const doneCount = checkedItems.filter(Boolean).length;

  const autoMarkQuest = useCallback((questId: string, shouldMark: boolean) => {
    setMasteryData((prev) => {
      const qs = prev.quests[questId];
      if (!qs) return prev;
      const alreadyDone = isTodayCompleted(qs.completedDates);
      const streak = calcStreak(qs.completedDates, qs.targetDays);
      const isComplete = streak >= qs.targetDays;

      if (shouldMark && alreadyDone) return prev;
      if (!shouldMark && !alreadyDone) return prev;
      if (isComplete && !alreadyDone) return prev;

      const updated: MasteryData = {
        ...prev,
        quests: {
          ...prev.quests,
          [questId]: { ...qs, completedDates: toggleToday(qs.completedDates) },
        },
      };
      saveMasteryData(updated);
      onPhaseProgressChange?.(calcProgressPct(updated));
      return updated;
    });
  }, [onPhaseProgressChange]);

  const toggleTask = useCallback((idx: number) => {
    setCheckedItems((prev) => {
      const next = [...prev];
      next[idx] = !next[idx];
      const questId = questIdFromTag(tasks[idx]?.tag || '');
      if (questId) autoMarkQuest(questId, next[idx]);
      return next;
    });
  }, [tasks, autoMarkQuest]);

  const handleSave = () => {
    autoMarkQuest('daily-checkin', true);
    onSaveDay(checkedItems.filter(Boolean).length, 3);
  };

  const handleMasteryToggle = useCallback((id: string) => {
    setMasteryData((prev) => {
      const qs = prev.quests[id];
      if (!qs) return prev;
      const streak = calcStreak(qs.completedDates, qs.targetDays);
      if (streak >= qs.targetDays && !isTodayCompleted(qs.completedDates)) return prev;
      const updated: MasteryData = {
        ...prev,
        quests: {
          ...prev.quests,
          [id]: { ...qs, completedDates: toggleToday(qs.completedDates) },
        },
      };
      saveMasteryData(updated);
      onPhaseProgressChange?.(calcProgressPct(updated));
      return updated;
    });
  }, [onPhaseProgressChange]);

  const handlePickClick = useCallback(() => {
    const pickId = masteryData.pickId;
    if (!pickId) return;
    setHighlightedQuestId(pickId);
    setTimeout(() => setHighlightedQuestId(null), 2000);
    document.getElementById(`quest-row-${pickId}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, [masteryData.pickId]);

  useEffect(() => {
    setMasteryData(initMastery());
  }, [session.current_phase]);

  const shortTag = (tag: string) => tag.split('·')[1]?.trim() || tag;

  return (
    <>
      <DailyLearnCard cyclePhaseName={session.cycle_phase_name} />
      <div className="today-single">
        <div className="tasks-card">

          {/* ── Inline check-in ── */}
          <div className="checkin-inline">
            <div className="checkin-inline-row">
              <span className="checkin-inline-label">Energy</span>
              <div className="checkin-chips">
                {PROTOCOL.energy.map((e) => (
                  <button
                    key={e}
                    className={`checkin-chip ${e === session.energy ? 'active' : ''}`}
                    onClick={() => onEnergyChange(e)}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>
            <div className="checkin-inline-row">
              <span className="checkin-inline-label">Stress</span>
              <div className="checkin-chips">
                {PROTOCOL.stress.map((s) => (
                  <button
                    key={s}
                    className={`checkin-chip ${s === session.stress ? 'active' : ''}`}
                    onClick={() => onStressChange(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* ── Tasks header ── */}
          <div className="tasks-header">
            <div className="tasks-header-left">
              <h3>Today with Camryn</h3>
              <p>3 actions — phase, cycle &amp; energy matched</p>
            </div>
            <div className="tier-badge">{tier.tone}</div>
          </div>

          {tasks.map((task, idx) => {
            const isCycleRow = idx === 1;
            if (isCycleRow) {
              return (
                <CycleActionTile
                  key={idx}
                  taskTitle={task.title}
                  taskBody={task.body}
                  checked={checkedItems[idx]}
                  expanded={expanded === idx}
                  phaseName={shortTag(task.tag)}
                  cyclePhase={session.cycle_phase_name}
                  onCheck={() => toggleTask(idx)}
                  onExpand={(e) => { e.stopPropagation(); setExpanded(expanded === idx ? null : idx); }}
                />
              );
            }
            return (
              <div
                key={idx}
                className={`task-row ${checkedItems[idx] ? 'done' : ''}`}
                onClick={() => toggleTask(idx)}
              >
                <div className={`task-checkbox ${checkedItems[idx] ? 'checked' : ''}`}>
                  {checkedItems[idx] && (
                    <svg width="11" height="9" viewBox="0 0 11 9" fill="none">
                      <path d="M1 4.5L4 7.5L10 1" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <div className="task-row-content">
                  <div className="task-row-title">{task.title}</div>
                  <div
                    className={`task-row-body ${expanded === idx ? 'expanded' : ''}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setExpanded(expanded === idx ? null : idx);
                    }}
                  >
                    {task.body}
                  </div>
                </div>
                <div className="task-tag">{shortTag(task.tag)}</div>
              </div>
            );
          })}

          <div className="tasks-footer">
            <span className="progress-text">{doneCount}/3</span>
            <div className="progress-bar">
              <div className="progress-bar-fill" style={{ width: `${(doneCount / 3) * 100}%` }} />
            </div>
            <button className="save-btn-inline" onClick={handleSave}>
              Save today
            </button>
          </div>

          {onNavigateToJournal && (
            <div className="tasks-journal-link">
              <button type="button" className="cycle-link" onClick={onNavigateToJournal}>
                Talk to Camryn about today →
              </button>
            </div>
          )}
        </div>

        {/* ── Mastery collapsible ── */}
        <div className="mastery-collapse">
          <button
            className="mastery-collapse-toggle"
            onClick={() => setMasteryOpen((v) => !v)}
            aria-expanded={masteryOpen}
          >
            <span className="mastery-collapse-label">Mastery unlocks</span>
            <span className="mastery-collapse-hint">{phase.name} phase progress</span>
            <svg
              className={`mastery-collapse-chevron ${masteryOpen ? 'open' : ''}`}
              width="14" height="14" viewBox="0 0 14 14" fill="none"
            >
              <path d="M3 5l4 4 4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          {masteryOpen && (
            <div className="mastery-collapse-body">
              <MasteryCard
                phaseName={phase.name}
                data={masteryData}
                highlightedId={highlightedQuestId}
                onToggle={handleMasteryToggle}
                onPickClick={handlePickClick}
              />
            </div>
          )}
        </div>
      </div>
    </>
  );
}
