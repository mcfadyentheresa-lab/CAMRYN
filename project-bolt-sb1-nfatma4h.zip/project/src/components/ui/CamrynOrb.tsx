import { useRef, useCallback } from 'react';

interface CamrynOrbProps {
  size?: number;
  className?: string;
  onClick?: () => void;
  'aria-label'?: string;
}

export default function CamrynOrb({
  size = 36,
  className = '',
  onClick,
  'aria-label': ariaLabel = 'Camryn',
}: CamrynOrbProps) {
  const orbRef = useRef<HTMLButtonElement | HTMLDivElement>(null);
  const bodyRef = useRef<HTMLSpanElement>(null);
  const coreRef = useRef<HTMLSpanElement>(null);
  const hlARef = useRef<HTMLSpanElement>(null);
  const hlBRef = useRef<HTMLSpanElement>(null);
  const refrARef = useRef<HTMLSpanElement>(null);
  const lensRef = useRef<HTMLSpanElement>(null);

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    const el = orbRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    const dx = (x - 0.5) * 4;
    const dy = (y - 0.5) * 4;

    if (bodyRef.current)  bodyRef.current.style.transform  = `rotate(${dx * 0.6}deg)`;
    if (coreRef.current)  coreRef.current.style.transform  = `translate(${dx * 0.35}px, ${dy * 0.35}px) scale(1.02)`;
    if (hlARef.current)   hlARef.current.style.transform   = `translate(${dx * 0.55}px, ${dy * 0.45}px) rotate(-24deg)`;
    if (hlBRef.current)   hlBRef.current.style.transform   = `translate(${dx * 0.35}px, ${dy * 0.3}px) rotate(24deg)`;
    if (refrARef.current) refrARef.current.style.transform = `translate(${dx * 0.25}px, ${dy * 0.25}px)`;
    if (lensRef.current)  lensRef.current.style.transform  = `translateX(${dx * 0.25}px) scaleX(1.02)`;
  }, []);

  const onPointerLeave = useCallback(() => {
    if (bodyRef.current)  bodyRef.current.style.transform  = '';
    if (coreRef.current)  coreRef.current.style.transform  = '';
    if (hlARef.current)   hlARef.current.style.transform   = '';
    if (hlBRef.current)   hlBRef.current.style.transform   = '';
    if (refrARef.current) refrARef.current.style.transform = '';
    if (lensRef.current)  lensRef.current.style.transform  = '';
  }, []);

  const inner = (
    <>
      <span className="camryn-orb-shadow" />
      <span className="camryn-orb-body" ref={bodyRef}>
        <span className="camryn-orb-rim" />
        <span className="camryn-orb-inner-glow" />
        <span className="camryn-orb-core" ref={coreRef} />
        <span className="camryn-orb-highlight camryn-orb-highlight-a" ref={hlARef} />
        <span className="camryn-orb-highlight camryn-orb-highlight-b" ref={hlBRef} />
        <span className="camryn-orb-highlight camryn-orb-highlight-c" />
        <span className="camryn-orb-refraction camryn-orb-refraction-a" ref={refrARef} />
        <span className="camryn-orb-refraction camryn-orb-refraction-b" />
        <span className="camryn-orb-caustic" />
        <span className="camryn-orb-bottom-lens" ref={lensRef} />
      </span>
    </>
  );

  const style = { '--camryn-orb-size': `${size}px` } as React.CSSProperties;

  if (onClick) {
    return (
      <div className={`camryn-orb-wrap ${className}`} style={style}>
        <button
          className="camryn-orb"
          ref={orbRef as React.RefObject<HTMLButtonElement>}
          onClick={onClick}
          onPointerMove={onPointerMove}
          onPointerLeave={onPointerLeave}
          aria-label={ariaLabel}
        >
          {inner}
        </button>
      </div>
    );
  }

  return (
    <div
      className={`camryn-orb-wrap camryn-orb ${className}`}
      ref={orbRef as React.RefObject<HTMLDivElement>}
      onPointerMove={onPointerMove}
      onPointerLeave={onPointerLeave}
      style={style}
    >
      {inner}
    </div>
  );
}
